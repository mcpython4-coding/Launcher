These is an example mod for these project.
It demonstrates only how to do basic things.