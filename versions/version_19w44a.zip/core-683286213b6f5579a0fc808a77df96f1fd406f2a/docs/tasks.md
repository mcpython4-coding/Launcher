These is an tasklist covering all different tasks these project has.

It is like an collection with tasks which have not been thought over when to be implement.
