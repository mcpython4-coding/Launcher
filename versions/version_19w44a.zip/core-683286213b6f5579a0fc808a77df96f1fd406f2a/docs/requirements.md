A file for quick and dirty pip install.
Usage: 
```shell script
pip install -r requirements.txt
```